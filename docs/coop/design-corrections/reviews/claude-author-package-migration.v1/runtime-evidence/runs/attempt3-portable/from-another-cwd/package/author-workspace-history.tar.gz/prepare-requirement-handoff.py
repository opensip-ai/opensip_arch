from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
source=ROOT.parent/'consumer-b.v13/requirements.json';d=json.loads(source.read_text())
support={}
def add(ids,paths):
 for id in ids.split():support[id]=paths
add('R-RUN-TS R-RUN-TS-NODE-MODULES R-RUN-TS-CONFIG-DEPS R-SCOPEDOCUMENT-IN-ANALYSIS-SPEC R-IMPORTED-PAYLOAD-IN-GRAPH R-RUN-CLONES-L0-AND-NORMALIZED R-RUN-CLONES-CUSTODY',['checkpoint3-owner/report.json'])
add('R-RUN-RUST R-RUN-SYNTAX-CODE R-RUN-SYNTAX-DATA R-RUN-NO-COMPILER-UNIT R-RUN-UNAVAILABLE-SEMANTIC',['normalized-examples6-owner/report.json'])
add('R-RUN-RUST-MIXED-EDITION R-RUN-RUST-TARGET-EDITION R-RUN-RUST-BODY-DIALECT R-RUN-RUST-SAME-FILE-TWO-EDITIONS R-RUN-RUST-PARTIAL-EMPTY-CLONES R-RUN-RUST-HASH-MARKER R-RUN-RUST-STABLE-BODY-ON-OWNERSHIP-CHANGE R-RUN-RUST-LARGE-EDITION-MAP R-RUN-RUST-VERSION-COMPONENT R-CLONE-DEFICIENCY-PAIRING',['author-properties.json','normalized-examples6-owner/report.json','rust-selection-examples1-owner/report.json'])
add('R-REPLAY-TAMPER R-NEGATIVE-FIRST-REFUSAL',['semantic-controls1/assessment.json'])
add('R-REPLAY-AFTER-ADMISSION R-OBJECT-TABLE-FRAMES R-ROOT-ADMISSION-EXPORT R-RETAINED-ARTIFACTS-IN-CLOSURE',['checkpoint3-owner/report.json','normalized-examples6-owner/report.json','rust-selection-examples1-owner/report.json'])
add('R-GRAPH-QUERY-OPERATION-DISCLOSURE-CURSOR',['query-checks1/assessment.json'])
assert set(support)<=set(r['id'] for r in d['requirements'])
rows=[]
for r in d['requirements']:
 rows.append({**r,'independentDisposition':'PENDING-ORIGINAL-INDEPENDENT-RECONSTRUCTION','authorSupport':support.get(r['id'],[]),'authorSupportStanding':'Supporting authored fixtures/reference results only; not a declaration that this requirement has been independently executed.' if r['id'] in support else 'No new author execution claimed for this item. Original independent charter remains unchanged.'})
report={'standing':'Review handoff, not a completion checklist or independent acceptance. The complete original charter, including all 123 requirements, 8 standing rules and 3 future items, remains intact.','originalRequirementsSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'requirements':rows,'standingRules':d['standing'],'futureQualification':d['futureQualification'],'independentAcceptance':False}
(ROOT/'original-requirement-handoff.json').write_text(json.dumps(report,indent=2)+'\n')
print('Preserved all 123 original requirements with explicit pending independent status; author evidence linked where relevant.')
