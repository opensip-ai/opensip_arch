"""Author diagnostics using frozen derivation; never constitutes independent evidence."""
from pathlib import Path
import importlib.util,json,sys
ROOT=Path(__file__).resolve().parent
F=Path('/tmp/opensip-design-corrections/candidate-subject.v25/docs/coop/design-corrections/foundation')
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
T=load('author_transport',ROOT.parent/'check-blind13-exported-graphs.v4.py');R=load('author_reference_replay',F/'evaluator_replay_model.v3.py');M=R.M
cp=ROOT/sys.argv[1];out=ROOT/(sys.argv[1]+'-diagnostics');out.mkdir()
claim=json.loads((cp/'claims.json').read_text())[0]
objects,blobs=T.decode_store((cp/claim['path']).read_bytes(),M)
run=objects[claim['runId']][1];rid,owner=M.open_run_closure(run,objects,blobs)
seal=objects[run['evaluationSealId']][1];actual=objects[seal['proofBundleId']][1]
expected=R.derive(run['planId'],seal['executionPlanId'],seal['evaluatorClosure'],actual['evaluationInputRefs'],objects,blobs,owner)
diffs=[]
def walk(a,b,p=''):
 if type(a)!=type(b):diffs.append({'path':p,'actual':a,'expected':b});return
 if isinstance(a,dict):
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:diffs.append({'path':p+'/'+k,'actual':a.get(k),'expected':b.get(k)})
   else:walk(a[k],b[k],p+'/'+k)
 elif isinstance(a,list):
  if len(a)!=len(b):diffs.append({'path':p,'actual':a,'expected':b})
  else:
   for i,(x,y) in enumerate(zip(a,b)):walk(x,y,p+'/'+str(i))
 elif a!=b:diffs.append({'path':p,'actual':a,'expected':b})
walk(actual,expected['proof'])
(out/'proof-differences.json').write_text(json.dumps(diffs,indent=2)+'\n')
(out/'expected-proof.json').write_text(json.dumps(expected['proof'],indent=2)+'\n')
(out/'actual-proof.json').write_text(json.dumps(actual,indent=2)+'\n')
print(json.dumps(diffs,indent=2))
