"""Author assessment of inherited non-TS example builders; no completeness claim."""
from pathlib import Path
import json,sys,traceback
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'output'))
from helpers import runs
out=ROOT/'other-examples2';out.mkdir();claims=[];construction=[]
for name,fn in [('rust',runs.build_rust_run),('rust-partial',runs.build_rust_partial),('syntax-code',lambda:runs.build_syntax_run(data_document=False)),('syntax-data',lambda:runs.build_syntax_run(data_document=True))]:
 try:
  graph=fn();namefile=name+'.store.json';(out/namefile).write_text(json.dumps(graph['store'].export(),indent=2,sort_keys=True)+'\n');claims.append({'name':name,'path':namefile,'runId':graph['runId']});construction.append({'name':name,'constructed':True})
 except Exception as e:construction.append({'name':name,'constructed':False,'error':str(e),'traceback':traceback.format_exc()})
(out/'claims.json').write_text(json.dumps(claims,indent=2)+'\n');(out/'construction.json').write_text(json.dumps(construction,indent=2)+'\n');print(json.dumps(construction,indent=2))
